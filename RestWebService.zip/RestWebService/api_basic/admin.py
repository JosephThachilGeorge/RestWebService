from django.contrib import admin
from .models import Consultant

# Register your models here.


admin.site.register(Consultant)
