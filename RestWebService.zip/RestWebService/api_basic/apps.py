from django.apps import AppConfig


class ApiBasicConfig(AppConfig):
    name = 'api_basic'
