from django.urls import path
from .views import consultant_list, consultant_detail, ConsultantAPIView, ConsultantDetails, GenericAPIView

urlpatterns = [
   # path('consultant/', consultant_list),
   path('consultant/', ConsultantAPIView.as_view()),
   # path('detail/<int:pk>/' , consultant_detail)
    path('detail/<int:id>/' , ConsultantDetails.as_view()),
    path('generic/consultant/<int:id>/', GenericAPIView.as_view()),
    path('generic/consultant/', GenericAPIView.as_view())

]
