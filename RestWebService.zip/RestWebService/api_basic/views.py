from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from rest_framework.parsers import JSONParser
from .models import Consultant
from .serializers import ConsultantSerializer
from rest_framework.decorators import api_view 
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework import mixins
from rest_framework import generics
from rest_framework.authentication import SessionAuthentication, BasicAuthentication, TokenAuthentication
from rest_framework.permissions import IsAuthenticated 


# Create your views here.

class GenericAPIView(generics.GenericAPIView, mixins.ListModelMixin, mixins.CreateModelMixin,
mixins.UpdateModelMixin, mixins.RetrieveModelMixin,mixins.DestroyModelMixin):
    serializer_class = ConsultantSerializer
    queryset = Consultant.objects.all()

    lookup_field= 'id'
    #authentication_classes = [SessionAuthentication, BasicAuthentication]
   # authentication_classes = [TokenAuthentication]
   # permission_classes = [IsAuthenticated]

    def get(self, request, id = None):
        if id:
            return self.retrieve(request)
        else:    
            return self.list(request)
    def post(self, request):
        return self.create(request)
    def put(self, reuest, id =None):
        return self.update(reuest, id)

    def delete(self, request, id):
        return self.destroy(request, id)    










class ConsultantAPIView(APIView):
    def get(self, request):
        consultants = Consultant.objects.all()
        serializer = ConsultantSerializer(consultants, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ConsultantSerializer (data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)  
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ConsultantDetails(APIView): 

    def get_object(self, id):
        try:
             return Consultant.objects.get(id=id)

        except Consultant.DoesNotExist:
             return HttpResponse(status=status.HTTP_404_NOT_FOUND)

    def get(self,request, id):
        consultant = self.get_object(id)
        serializer = ConsultantSerializer(consultant)
        return Response(serializer.data) 

    def put(self, request, id):
        consultant = self.get_object(id)
        serializer = ConsultantSerializer(consultant, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST) 


    def delete(self, request, id):
        consultant = self.get_object(id)
        consultant.delete() 
        return Response(status=status.HTTP_204_NO_CONTENT)







@api_view(['GET','POST'])
def consultant_list(request):

    if request.method == 'GET':
        consultants = Consultant.objects.all()
        serializer = ConsultantSerializer(consultants, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = ConsultantSerializer (data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)  
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def consultant_detail(request, pk):
    try:
        consultant = Consultant.objects.get(pk=pk)

    except Consultant.DoesNotExist:
        return HttpResponse(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = ConsultantSerializer(consultant)
        return Response(serializer.data)

    elif request.method ==  'PUT':
        
        serializer = ConsultantSerializer(consultant, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    

    elif request.method == 'DELETE': 
        consultant.delete() 
        return Response(status=status.HTTP_204_NO_CONTENT)                    